from flask import Flask, Response, request, jsonify, redirect
from gevent.pywsgi import WSGIServer
from time import time
import logging
import sys, os

class APIHandler:

    def __init__ (self, controller, httpd_config, log_level = logging.DEBUG, log_handler = logging.StreamHandler(sys.stderr)):
        log_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.controller = controller
        self.httpd_config = httpd_config
        self.logger = logging.getLogger('APIHandler')
        self.logger.setLevel(log_level)
        self.logger.addHandler(log_handler)
        self.app = Flask(controller.getName(), static_folder='assets/', static_url_path='/static')
        self.app.config['JSON_SORT_KEYS'] = False
        self.app.config['JSON_PRESERVE_ORDER'] = True
        self.app.add_url_rule('/', 'monitor', self.redirect('/static/monitor/index.html'))
        self.app.add_url_rule('/instructor', 'instructor', self.redirect('/static/instructor/index.html'))
        self.app.add_url_rule('/api/get_ctf', 'get_ctf', self.getCtf, methods=['GET', 'OPTIONS'])
        self.app.add_url_rule('/api/get_events', 'get_events', self.getEvents, methods=['GET', 'OPTIONS'])
        self.app.add_url_rule('/api/get_schema', 'get_schema', self.getSchema, methods=['GET', 'OPTIONS'])
        self.app.add_url_rule('/api/get_answer', 'get_answer', self.getAnswer, methods=['GET', 'OPTIONS'])
        self.app.add_url_rule('/api/drop_session', 'drop_session', self.dropSesion, methods=['GET', 'OPTIONS'])
        self.app.add_url_rule('/api/add_session', 'add_session', self.addSession, methods=['POST', 'OPTIONS'])
        self.events = []

    def redirect(self, target):
        def do_redir():
            return redirect(target)

        return do_redir

    def start(self):
        self.logger.info('Starting APIHandler...')
        self.controller.setEventHandler(self.handleEvent)
        if not self.controller.start():
            self.logger.error('Failed to start controller')
            return False

        httpd_conf = self.httpd_config

        if ('use_ssl' in httpd_conf and httpd_conf['use_ssl']):
            self.server = WSGIServer((httpd_conf['host'], httpd_conf['port']), self.app, keyfile=httpd_conf['ssl_key_file'], certfile=httpd_conf['ssl_cert_file'], log=None, error_log=self.logger)
        else: self.server = WSGIServer((httpd_conf['host'], httpd_conf['port']), self.app, log=None, error_log=self.logger)
        self.logger.info('APIHandler Ready.')
        self.server.serve_forever() # TODO

    def stop(self):
        self.server.stop()
        self.controller.setEventHandler(None)
        self.controller.stop()
        
    def getCtf(self):
        if request.method == 'OPTIONS': return self._get()
        ctf = self.controller.getCtf()
        ctf['last_event'] = len(self.events)
        return self._ar(jsonify({'ok': True, 'result': ctf})), 200

    def getAnswer(self):
        if request.method == 'OPTIONS': return self._get()
        if (not 'token' in request.args or request.args['token'] != self.httpd_config['token']):
            return self._ar(jsonify({'ok': False, 'error': 'Invalid token.'})), 400
        if (not 'session_id' in request.args):
            return self._ar(jsonify({'ok': False, 'error': 'Missing session ID'})), 400
        return self._ar(jsonify({'ok': True, 'result': self.controller.getAnswer(int(request.args['session_id']))})), 200

    def dropSesion(self):
        if request.method == 'OPTIONS': return self._get()
        if (not 'token' in request.args or request.args['token'] != self.httpd_config['token']):
            return self._ar(jsonify({'ok': False, 'error': 'Invalid token.'})), 400
        if (not 'session_id' in request.args):
            return self._ar(jsonify({'ok': False, 'error': 'Missing session ID'})), 400
        ok, msg = self.controller.dropSession(int(request.args['session_id']))
        if ok: return self._ar(jsonify({'ok': True, 'result': msg})), 200
        return self._ar(jsonify({'ok': False, 'error': msg})), 400

    def addSession(self):
        if request.method == 'OPTIONS': return self._post()
        if not request.is_json: return self._ar(jsonify({'ok': False, 'error': 'Request body is not JSON.'})), 400
        req = request.get_json()
        if (not 'token' in req or req['token'] != self.httpd_config['token']):
            return self._ar(jsonify({'ok': False, 'error': 'Invalid token.'})), 400
        if (not 'configuration' in req):
            return self._ar(jsonify({'ok': False, 'error': 'Missing Configuration'})), 400
        ok, msg = self.controller.addSession(req['configuration'])
        if ok: return self._ar(jsonify({'ok': True, 'result': msg})), 200
        return self._ar(jsonify({'ok': False, 'error': msg})), 400
    
    def getEvents(self):
        if request.method == 'OPTIONS': return self._get()
        if (not 'offset' in request.args): return self._ar(jsonify({'ok': False, 'error': 'missing offset value.'})), 400
        return self._ar(jsonify({'ok': True, 'result': self.getEvent(int(request.args['offset']))})), 200

    def handleEvent(self, event):
        if 'event_type' in event and event['event_type'] == 'terminate':
            self.logger.info('Got termination request, stopping server')
            self.server.stop()

        if 'event_type' in event and event['event_type'] == 'success':
            if 'team_id' in event:
                flag_found = False
                flags = os.listdir('assets/flags')
                for flag in flags:
                    fn, fe = os.path.splitext(flag)
                    if fn == 'team{}'.format(event['team_id']):
                        flag_url = '/static/flags/{}'.format(flag)
                        event['flag_url'] = flag_url
                        flag_found = True
                        break

                if not flag_found: self.logger.warn('No flag image found for team {}.'.format(event['team_id']))

            else:
                self.logger.warn('No team_id in success event.')
        
        event['time'] = time()
        event['event_id'] = len(self.events)
        self.events.append(event)

    def getEvent(self, offset):
        if (offset > len(self.events)): return []
        else: return self.events[offset:]
    
    def getSchema(self):
        if request.method == 'OPTIONS': return self._get()
        schema = self.controller.getSchema()
        if type(schema) == str: # FIXME: why does flask break the dict order?
            return Response('{{"ok": true, "result": {}}}'.format(schema), status=200, mimetype='application/json')
        else:
            return self._ar(jsonify({'ok': True, 'result': self.controller.getSchema()})), 200 

    def _get(self):
        res = Response('', 204)
        res.headers['Access-Control-Allow-Methods'] = 'GET'
        res.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        return self._ar(res)
    
    def _post(self):
        res = Response('', 204)
        res.headers['Access-Control-Allow-Methods'] = 'POST'
        res.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        return self._ar(res)
    
    def _ar(self, res):
        res.headers['Access-Control-Allow-Origin'] = '*'
        return res