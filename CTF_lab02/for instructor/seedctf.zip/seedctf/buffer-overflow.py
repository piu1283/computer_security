#!/usr/bin/env python3
from controller import BufferOverflowController
from framework import APIHandler
from os import geteuid, setegid, setegid
from sys import stderr
from subprocess import Popen, PIPE
import argparse
import json
import logging

logger = logging.getLogger('BufferOverflowCtf')
logger.setLevel(logging.INFO)
log_handler = logging.StreamHandler(stderr)
log_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
logger.addHandler(log_handler)

parser = argparse.ArgumentParser(description='start the buffer-overflow CTF')
parser.add_argument('--config', dest='config', required=False, help='path to CTF configration file')
parser.add_argument('--host', dest='host', required=False, help='the host for frontend to bind to (default: 0.0.0.0)', default='0.0.0.0')
parser.add_argument('--port', dest='port', required=False, type=int, help='the port for frontend to bind to (default: 80 for http, 443 for https)', default=80)
parser.add_argument('--ssl', dest='ssl', action='store_true', required=False, help='enable https for frontend')
parser.add_argument('--cert', dest='cert', required=False, help='path to ssl certificate file', default='')
parser.add_argument('--key', dest='key', required=False, help='path to ssl key file', default='')
parser.add_argument('--disable-aslr', dest='disable_aslr', action='store_true', help='disable ASLR if enabled. ASLR will be re-enabled when the program quit if it was previously on')
parser.add_argument('--token', dest='token', required=True, help='the instructor token')
args = parser.parse_args()
config = {}

old_va_value = '2'

if args.config is not None:
	f = open(args.config, 'r')
	try:
		config = json.load(f)
	except:
		raise
	finally:
		f.close()
else: config = []

if geteuid() != 0 and args.disable_aslr:
	logger.error('root needed for --disable-aslr')
	exit(1)

if args.disable_aslr:
	logger.info('Disabling ASLR...')
	sysctl_read = Popen(['sysctl', '-n', 'kernel.randomize_va_space'], stdout=PIPE)
	old_va_value = sysctl_read.communicate()[0].decode('unicode_escape')[:-1]
	sysctl_read.wait()
	if sysctl_read.returncode != 0:
		exit(sysctl_read.returncode)
	
	logger.info('Old ASLR value: {}'.format(old_va_value))
	sysctl_write = Popen(['sysctl', '-w', 'kernel.randomize_va_space=0'])
	sysctl_write.wait()
	if sysctl_write.returncode != 0:
		exit(sysctl_write.returncode)


controller = BufferOverflowController.BufferOverflowController(config, log_level=logging.INFO)

bind_port = args.port
if args.ssl and args.port == 80: bind_port = 443

httpd_config = {
	'token': args.token,
	'host': args.host,
	'port': bind_port,
	'use_ssl': args.ssl,
	'ssl_key_file': args.key,
	'ssl_cert_file': args.cert
}

api = APIHandler.APIHandler(controller, httpd_config, log_level=logging.INFO)

try:
    api.start()
except KeyboardInterrupt:
	logger.info('Got KeyboardInterrupt, stopping...')
	api.stop()
except:
	raise
finally:
	if args.disable_aslr:
		logger.info('Restoreing old ASLR value: {}...'.format(old_va_value))
		sysctl_write = Popen(['sysctl', '-w', 'kernel.randomize_va_space={}'.format(old_va_value)])
