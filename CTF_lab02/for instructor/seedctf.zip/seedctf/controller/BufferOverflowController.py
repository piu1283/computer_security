from subprocess import Popen, PIPE, STDOUT
from select import select
from threading import Thread, Event
import logging
import sys
import os
import time
import re
import random
import shutil
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class BufferOverflowController:

    class FlagChangeHandler(FileSystemEventHandler):
        def __init__(self, cb):
            self.callback = cb

        def on_any_event(self, event):
            if event.is_directory: return None
            # FIXME: some 'touch' trigger 'create' event only while other trigger both 'created' and 'modified'
            elif event.event_type == 'modified': 
                self.callback(event.src_path)

    def __init__ (self, configs, log_level = logging.DEBUG, log_handler = logging.StreamHandler(sys.stderr)):
        log_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.configs = configs
        self.logger = logging.getLogger('BufferOverflowController')
        self.logger.setLevel(log_level)
        self.logger.addHandler(log_handler)
        self.sessions = []
        self.servers = []
        self.answers = []
        self.running = False
        self.eventHandler = None
        self.monitor_thread = None
        self.flag_observer = Observer()
        self.flag_observer.schedule(self.FlagChangeHandler(self.handleFlagChange), '/tmp/CTF')
        self.session_id = 0
        self.dummy_sizes = [0, random.randint(0, 1000), random.randint(0, 1000), random.randint(0, 1000), random.randint(0, 1000)]
        self.team_re = re.compile('^team([0-9]+)$')

    def getName(self):
        return 'Buffer Overflow CTF'

    def getSchema(self):
        return """{"$schema":"http://json-schema.org/draft-04/schema#","$id":"http://json-schema.org/draft-04/schema#","title":"Buffer Overflow Session Configuration","type":"object","properties":{"level":{"type":"integer","enum":[1,2,3,4],"description":"Difficulty level for the session.","default":1},"buffer_size":{"type":"integer","description":"The size of buffer."},"host":{"type":"string","description":"IP address of the host that runs the SEED VM."},"port":{"type":"integer","description":"Port number that the new session should bind on."},"team_id":{"type":"integer","description":"What team is this session for?"}},"required":["level","host","port","team_id","buffer_size"],"dependencies":{"level":{"oneOf":[{"properties":{"level":{"enum":[1,4]}}},{"properties":{"level":{"enum":[2]},"buffer_high":{"type":"integer","description":"The value to be added to the buffer size: the upper bound of the range."},"buffer_low":{"type":"integer","description":"The value to be deducted from the buffer size: the lower bound of the range"}},"required":["buffer_high","buffer_low"]},{"properties":{"level":{"enum":[3]},"buffer_high":{"type":"integer","description":"The value to be added to the buffer size: the upper bound of the range."},"buffer_low":{"type":"integer","description":"The value to be deducted from the buffer size: the lower bound of the range"},"address_mask":{"type":"string","description":"The address mask."}},"required":["buffer_high","buffer_low","address_mask"]}]}}}"""

    def setEventHandler(self, handler):
        self.eventHandler = handler

    def evalEvent(self, event):
        if event['session_id'] >= 0:
            sessions = [s for s in self.sessions if s['id'] == event['session_id']]
            if (len(sessions) != 1):
                self.logger.warn('session ID duplicated or missing')
                return False

            session = sessions[0]

            if (event['event_type'] == 'update'):
                session[event['update']['field']] = event['update']['value']

            if (event['event_type'] == 'success'):
                session['successes'] += 1

            if (event['event_type'] == 'trial'):
                session['trials'] += 1

        if self.eventHandler is not None: self.eventHandler(event)
        else: self.logger.info('Event Handler does not exists, skipped')

    def getCtf(self):
        return {'name': 'Buffer Overflow', 'sessions': [s for s in self.sessions if s['running']]}

    def stop (self):
        self.logger.info('Stopping Controller...')
        self.running = False
        self.flag_observer.stop()
        shutil.rmtree('/tmp/CTF')
        [s['server'].kill() for s in self.servers]
        self.logger.info('Controller Stopped, sending termination request.')
        self.evalEvent({'event_type': 'terminate', 'session_id': -1})

    def start (self):
        if (self.running): return False
        self.running = True

        for config in self.configs:
            ok, msg = self.addSession(config)    
            if not ok: self.logger.error('Error when adding session: {}'.format(msg))    

        if not os.path.exists('/tmp/CTF'): os.makedirs('/tmp/CTF')
        self.flag_observer.start()

        return True

    def addSession(self, config):
        try:
            new_session_id = self.session_id

            self.logger.info('Starting session {}...'.format(new_session_id))

            gcc = Popen([
                'gcc',
                '-DBUF_SIZE={}'.format(config['buffer_size']),
                '-DDUMMY_SIZE={}'.format(self.dummy_sizes[config['level']]),
                '-o/tmp/ctf_server_{}'.format(new_session_id),
                '-zexecstack',
                '-fno-stack-protector', 
                'assets/buffer-overflow/bof_vulnerable_server.c'
                ], stdin=PIPE, stderr=PIPE)
            
            stderr = gcc.communicate()[1]

            gcc.wait()
            if gcc.returncode != 0:
                self.logger.error('Failed to compile server: {}'.format(stderr.decode('unicode_escape')))
                return False, 'Failed to compile server'
            
            self.logger.info('Compiled server for session {}.'.format(new_session_id))

            host_str = config['host']

            server_str = '{}:{}'.format(host_str, config['port'])

            s_sessions = [session for session in self.sessions if session['running'] and session['server'] == server_str]
            t_sessions = [session for session in self.sessions if session['running'] and session['team_id'] == config['team_id']]

            if (len(t_sessions) != 0):
                self.logger.warn('Session for team {} already running.'.format(config['team_id']))
                return False, 'Session for this team already exist.'

            if (len(s_sessions) != 0):
                self.logger.warn('There is session running on {}'.format(server_str))
                return False, 'There is session running on {}'.format(server_str)

            session = {
                'id': new_session_id,
                'team_id': config['team_id'],
                'name': 'Buffer Overflow Level {}: Team {}'.format(config['level'], config['team_id']),
                'server': server_str,
                'trials': 0,
                'successes': 0,
                'hints': 'N/A',
                'running': True
            }

            self.sessions.append(session)

            self.answers.append('Answer not avaliable yet.')

            if config['level'] == 1 or config['level'] == 4: server = Popen([
                '/tmp/ctf_server_{}'.format(new_session_id),
                '-l', str(config['level']),
                '-p', str(config['port']),
                '-b', '0.0.0.0'
            ], stdin=PIPE, stdout=PIPE, bufsize=0)

            if config['level'] == 2: server = Popen([
                '/tmp/ctf_server_{}'.format(new_session_id),
                '-l', str(config['level']),
                '-p', str(config['port']),
                '-b', '0.0.0.0',
                '-S', str(config['buffer_high']),
                '-s', str(config['buffer_low'])
            ], stdin=PIPE, stdout=PIPE, bufsize=0)

            if config['level'] == 3: server = Popen([
                '/tmp/ctf_server_{}'.format(new_session_id),
                '-l', str(config['level']),
                '-p', str(config['port']),
                '-b', '0.0.0.0',
                '-S', str(config['buffer_high']),
                '-s', str(config['buffer_low']),
                '-m', config['address_mask']
            ], stdin=PIPE, stdout=PIPE, bufsize=0)

            monitor = Thread(target=self.serverMonitor, args=(new_session_id, server.stdout, ))
            monitor.start()

            self.servers.append({'server': server, 'monitor': monitor})
            self.session_id += 1

            self.logger.info('Started session {}.'.format(new_session_id))
            self.evalEvent({'session_id': new_session_id, 'event_type': 'new_session', 'new_session': session.copy()})
            return True, str(new_session_id)
        except:
            exc_info = sys.exc_info()
            self.logger.warn('Failed to start session: {}'.format(exc_info))
            return False, str(exc_info)

    def dropSession(self, session_id):
        if session_id > len(self.sessions) - 1:
            self.logger.warn('drop_session: bad session id {}'.format(session_id))
            return False, 'No such session'
        if not self.sessions[session_id]['running']:
            return False, 'Session {} was not running'.format(session_id)
        self.logger.info('Dropping session {}...'.format(session_id))
        self.evalEvent({'session_id': session_id, 'event_type': 'drop_session'})
        self.sessions[session_id]['running'] = False
        self.servers[session_id]['server'].kill()
        self.logger.info('Dropped session {}.'.format(session_id))
        return True, session_id

    def getAnswer(self, session_id):
        if session_id > len(self.answers) - 1:
            self.logger.warn('get_answer: bad session id {}'.format(session_id))
            return 'Bad session ID'
        return self.answers[session_id]

    def handleFlagChange(self, path):
        fn, _ = os.path.splitext(os.path.basename(path))
        team = self.team_re.search(fn)
        if team is None:
            self.logger.warn('Unknow team {}'.format(fn))
            return None

        team_id = int(team.group(1))
        session_ids = [session['id'] for session in self.sessions if session['team_id'] == team_id and session['running']]

        if (len(session_ids) != 1):
            self.logger.warn('Flag capture: Bad team ID {}'.format(team_id))
            return None

        session_id = session_ids[0]
        
        self.logger.info('Session {}: Team {} Got Flag!'.format(session_id, team_id))
        self.evalEvent({'session_id': session_id, 'event_type': 'success', 'team_id': team_id})

    def serverMonitor(self, session_id, fd):
        self.logger.info('Server monitor started for session {}'.format(session_id))
        ready = False
        while self.sessions[session_id]['running']:
            line = fd.readline()
            if not line:
                if self.sessions[session_id]['running']:
                    self.logger.error('Session: {}: server stopped unexpectedly.'.format(session_id))
                    self.dropSession(session_id)
                break
            server_line = line.decode('unicode_escape')
            if '#' not in server_line: 
                self.logger.error('Session: {}: unexpected respond from CTF server: {}'.format(session_id, server_line))
                self.dropSession(session_id)
                break
            [msg_type, msg] = server_line.split('#')
            msg = msg[:-1]

            if msg_type == 'err':
                self.logger.error('Session {}: Server error: {}'.format(session_id, msg))
                self.dropSession(session_id)
                break

            if ready and msg_type == 'trial':
                self.logger.debug('Session {}: Trial received from {}'.format(session_id, msg))
                self.evalEvent({'session_id': session_id, 'event_type': 'trial'})

            if msg_type == 'hints':
                self.logger.info('Session {}: Hints updated'.format(session_id))
                self.evalEvent({'session_id': session_id, 'event_type': 'update', 'update': {'field': 'hints', 'value': msg}})

            if msg_type == 'ans':
                self.logger.info('Session {}: Answer updated'.format(session_id))
                self.answers[session_id] = msg
                ready = True
        
        os.remove('/tmp/ctf_server_{}'.format(session_id))
        self.logger.info('Server monitor for session {} stopped'.format(session_id))